Configuration Deploy-DomainServices
{
    Param
    (
        [Parameter(Mandatory)]
        [String] $domainFQDN,
        [String] $domainSuffix,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential] $adminCredential
    )

    [String] $domainName = $domainFQDN.Split('.')[0]
    if ($domainName.Length -gt 15) {
        $domainName = $domainName.Substring(0,15)
    }

    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'ActiveDirectoryDsc'
    Import-DscResource -ModuleName 'ComputerManagementDsc'
    Import-DscResource -ModuleName 'NetworkingDsc'

    # Create the NetBIOS name and domain credentials based on the domain FQDN
    [String] $domainNetBIOSName = (Get-NetBIOSName -DomainFQDN $domainFQDN)
    [System.Management.Automation.PSCredential] $domainCredential = New-Object System.Management.Automation.PSCredential ("${domainNetBIOSName}\$($adminCredential.UserName)", $adminCredential.Password)

    $interface = Get-NetAdapter | Where-Object Name -Like 'Network' | Select-Object -First 1
        if (-not $interface) {
    $interface = Get-NetAdapter | Where-Object Name -Like 'Ethernet' | Select-Object -First 1
}
    $interfaceAlias = $($interface.Name)

    Node localhost
    {
        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        Script ConfigureGermanLanguage
        {
            SetScript = {
                # OS-Disk vergrößern
                $partition     = Get-Partition -DriveLetter C
                $sizeRemaining = Get-PartitionSupportedSize -DriveLetter C
                Resize-Partition -DriveLetter C -Size $sizeRemaining.SizeMax

                # DataDisk vergrößern
                $disk = Get-Disk -Number 1
                Initialize-Disk -Number 1 -PartitionStyle GPT -PassThru |
                    New-Partition -UseMaximumSize -DriveLetter F |
                    Format-Volume -FileSystem NTFS -NewFileSystemLabel "DataDisk" -Confirm:$false

                # Sprachpaket-ISO herunterladen und mounten
                New-Item -ItemType Directory -Path "C:\Temp" -Force | Out-Null
                Invoke-WebRequest -Uri "https://go.microsoft.com/fwlink/p/?linkid=2195333" -OutFile "C:\Temp\lang.iso"
                Mount-DiskImage -ImagePath "C:\Temp\lang.iso"

                # Laufwerksbuchstaben des gemounteten ISO finden
                $isoDrive = (Get-Volume | Where-Object FileSystemLabel -like '*SERVER*' | Select-Object -First 1).DriveLetter
                $langPath = "$isoDrive`:\LanguagesAndOptionalFeatures\"

                # lpksetup (CMD)
                Start-Process -FilePath "cmd.exe" -ArgumentList "/c lpksetup /i de-DE /p `"$langPath`" /s" -Wait -NoNewWindow

                # DISM
                $cabPath = Join-Path $langPath "Microsoft-Windows-Server-Language-Pack_x64_de-de.cab"
                Start-Process -FilePath "dism.exe" -ArgumentList "/online /Add-Package /PackagePath:`"$cabPath`"" -Wait -NoNewWindow

                # Sprache/Region/Zeit einstellen
                $lang = "de-DE"
                Set-WinUILanguageOverride -Language $lang
                Set-WinSystemLocale $lang
                Set-WinUserLanguageList -LanguageList $lang -Force
                Set-Culture -CultureInfo $lang
                Set-WinHomeLocation -GeoId 94
                Set-TimeZone -Id "W. Europe Standard Time"
                $ll = New-WinUserLanguageList $lang
                Set-WinUserLanguageList $ll -Force
            }

            TestScript = {
                $cultureOk   = (Get-Culture).Name -eq 'de-DE'
                $sysLocaleOk = (Get-WinSystemLocale).Name -eq 'de-DE'
                return ($cultureOk -and $sysLocaleOk)
            }

            GetScript = {
                $culture = (Get-Culture).Name
                $sysLoc  = (Get-WinSystemLocale).Name
                $uiLangs = (Get-WinUserLanguageList).LanguageTag -join ','

                # Script-Resource erwartet ein Hashtable mit String-Result 
                @{
                    Result = "Culture=$culture;SystemLocale=$sysLoc;UILang=$uiLangs"
                }
            }
        }

        PendingReboot ConfigureGermanLanguage
        {
            Name = 'ConfigureGermanLanguage'
            DependsOn = "[Script]ConfigureGermanLanguage"
        }

        WindowsFeature InstallDNS 
        { 
            Ensure = 'Present'
            Name = 'DNS'
        }

        WindowsFeature InstallDNSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-DNS-Server'
            DependsOn = '[WindowsFeature]InstallDNS'
        }

        DnsServerAddress SetDNS
        { 
            Address = '127.0.0.1'
            InterfaceAlias = $interfaceAlias
            AddressFamily = 'IPv4'
            DependsOn = '[WindowsFeature]InstallDNS'
        }

        WindowsFeature InstallADDS
        {
            Ensure = 'Present'
            Name = 'AD-Domain-Services'
            DependsOn = '[WindowsFeature]InstallDNS'
        }

        WindowsFeature InstallADDSTools
        {
            Ensure = 'Present'
            Name = 'RSAT-ADDS-Tools'
            DependsOn = '[WindowsFeature]InstallADDS'
        }

        ADDomain CreateADForest
        {
            DomainName = $domainFQDN
            Credential = $domainCredential
            SafemodeAdministratorPassword = $domainCredential
            ForestMode = 'WinThreshold'
            DatabasePath = 'C:\NTDS'
            LogPath = 'C:\NTDS'
            SysvolPath = 'C:\SYSVOL'
            DependsOn = '[DnsServerAddress]SetDNS', '[WindowsFeature]InstallADDS'
        }

        PendingReboot RebootAfterCreatingADForest
        {
            Name = 'RebootAfterCreatingADForest'
            DependsOn = "[ADDomain]CreateADForest"
        }
        WaitForADDomain WaitForDomainController
        {
            DomainName = $domainFQDN
            WaitTimeout = 600
            RestartCount = 3
            Credential = $domainCredential
            WaitForValidCredentials = $true
            DependsOn = "[PendingReboot]RebootAfterCreatingADForest"
        }
# Start neuer Block mit OUs
        ADOrganizationalUnit OU_EntraSync {
            Name        = 'EntraSync'
            Path        = "DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[WaitForADDomain]WaitForDomainController'
        }

        ADOrganizationalUnit OU_NoEntraSync {
            Name        = 'NoEntraSync'
            Path        = "DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[WaitForADDomain]WaitForDomainController'
        }

        ADOrganizationalUnit OU_Users {
            Name        = 'Users'
            Path        = "OU=EntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_EntraSync'
        }

        ADOrganizationalUnit OU_Groups {
            Name        = 'Groups'
            Path        = "OU=EntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_EntraSync'
        }

        ADOrganizationalUnit OU_NoEntraSyncUsers {
            Name        = 'Users'
            Path        = "OU=NoEntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_NoEntraSync'
        }

        ADOrganizationalUnit OU_NoEntraSyncGroups {
            Name        = 'Groups'
            Path        = "OU=NoEntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_NoEntraSync'
        }

        ADOrganizationalUnit OU_NoEntraSyncStorage {
            Name        = 'Storage'
            Path        = "OU=NoEntraSync,DC=$domainName,DC=local" # Domain anpassen
            Ensure      = 'Present'
            Credential  = $domainCredential
            DependsOn   = '[ADOrganizationalUnit]OU_NoEntraSync'
        }
# neuer Block mit OU's ENDE

        ADGroup AvdAccess {
            GroupName     = 'AvdAccess'
            Path          = "OU=Groups,OU=EntraSync,DC=$domainName,DC=local"
            Ensure        = 'Present'
            GroupScope    = 'Global'
            Category = 'Security'
            Credential    = $domainCredential
            DependsOn     = '[ADOrganizationalUnit]OU_Groups'
        }

        ADGroup AvdProfileAccess {
            GroupName     = 'AvdProfileAccess'
            Path          = "OU=Groups,OU=EntraSync,DC=$domainName,DC=local"
            Ensure        = 'Present'
            GroupScope    = 'Global'
            Category = 'Security'
            Credential    = $domainCredential
            DependsOn     = '[ADOrganizationalUnit]OU_Groups'
        }
    }
}

function Get-NetBIOSName {
    [OutputType([string])]
    param(
        [string] $domainFQDN
    )

    if ($domainFQDN.Contains('.')) {
        $length = $domainFQDN.IndexOf('.')
        if ( $length -ge 16) {
            $length = 15
        }
        return $domainFQDN.Substring(0, $length)
    }
    else {
        if ($domainFQDN.Length -gt 15) {
            return $domainFQDN.Substring(0, 15)
        }
        else {
            return $domainFQDN
        }
    }
}