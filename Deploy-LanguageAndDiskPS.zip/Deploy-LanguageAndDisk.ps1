
$partition     = Get-Partition -DriveLetter C
$sizeRemaining = Get-PartitionSupportedSize -DriveLetter C
Resize-Partition -DriveLetter C -Size $sizeRemaining.SizeMax

$disk = Get-Disk -Number 1
Initialize-Disk -Number 1 -PartitionStyle GPT -PassThru |
    New-Partition -UseMaximumSize -DriveLetter F |
    Format-Volume -FileSystem NTFS -NewFileSystemLabel "DataDisk" -Confirm:$false

New-Item -ItemType Directory -Path "C:\Temp" -Force | Out-Null
Invoke-WebRequest -Uri "https://go.microsoft.com/fwlink/p/?linkid=2195333" -OutFile "C:\Temp\lang.iso"

Mount-DiskImage -ImagePath "C:\Temp\lang.iso"

$timeout = (Get-Date).AddMinutes(5)
do {
    $isoDrive = (Get-Volume | Where-Object FileSystemLabel -like '*SERVER*' | Select-Object -First 1).DriveLetter
    Start-Sleep -Seconds 2
} until ($isoDrive -or (Get-Date) -gt $timeout)

if (-not $isoDrive) { throw "ISO wurde nicht erfolgreich gemountet." }

$langPath = "$isoDrive`:\LanguagesAndOptionalFeatures\"

Start-Process -FilePath "cmd.exe" -ArgumentList "/c lpksetup /i de-DE /p `"$langPath`" /s" -Wait -NoNewWindow

$cabPath = Join-Path $langPath "Microsoft-Windows-Server-Language-Pack_x64_de-de.cab"
Start-Process -FilePath "dism.exe" -ArgumentList "/online /Add-Package /PackagePath:`"$cabPath`"" -Wait -NoNewWindow

$timeout = (Get-Date).AddMinutes(5)
do {
    $pending = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"
    Start-Sleep -Seconds 2
} until (-not $pending -or (Get-Date) -gt $timeout)

$lang = "de-DE"
Set-WinUILanguageOverride -Language $lang
Set-WinSystemLocale $lang
Set-WinUserLanguageList -LanguageList $lang -Force
Set-Culture -CultureInfo $lang
Set-WinHomeLocation -GeoId 94
Set-TimeZone -Id "W. Europe Standard Time"
$ll = New-WinUserLanguageList $lang
Set-WinUserLanguageList $ll -Force
Restart-Computer -Force
