try {
    $partition = Get-Partition -DriveLetter C -ErrorAction Stop
    $sizeRemaining = Get-PartitionSupportedSize -DriveLetter C -ErrorAction Stop

    Resize-Partition -DriveLetter C -Size $sizeRemaining.SizeMax -ErrorAction Stop
}
catch {
    # Fehler explizit wegschlucken, egal welcher
    $null = $_
}

Install-Language de-DE
Set-SystemPreferredUILanguage -Language de-DE
Set-WinSystemLocale de-DE
Set-WinUserLanguageList -LanguageList de-DE -Force
Set-WinHomeLocation -GeoId 94
Set-TimeZone -Id 'W. Europe Standard Time'
Set-Culture -CultureInfo de-DE
Copy-UserInternationalSettingsToSystem -WelcomeScreen $true -NewUser $true
Set-WinUILanguageOverride -Language de-DE
Set-WinUserLanguageList -LanguageList de-DE -Force
Restart-Computer -Force