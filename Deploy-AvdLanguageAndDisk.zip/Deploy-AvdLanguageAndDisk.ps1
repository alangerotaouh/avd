try {
    $partition = Get-Partition -DriveLetter C -ErrorAction Stop
    $sizeRemaining = Get-PartitionSupportedSize -DriveLetter C -ErrorAction Stop

    Resize-Partition -DriveLetter C -Size $sizeRemaining.SizeMax -ErrorAction Stop
}
catch {
    # Fehler explizit wegschlucken, egal welcher
    $null = $_
}

Install-Language de-DE
Start-Sleep -Seconds 3600
Set-SystemPreferredUILanguage -Language de-DE
Start-Sleep -Seconds 10
Set-WinSystemLocale de-DE
Start-Sleep -Seconds 10
Set-WinUserLanguageList -LanguageList de-DE -Force
Start-Sleep -Seconds 10
Set-WinHomeLocation -GeoId 94
Start-Sleep -Seconds 10
Set-TimeZone -Id 'W. Europe Standard Time'
Start-Sleep -Seconds 10
Set-Culture -CultureInfo de-DE
Start-Sleep -Seconds 10
Copy-UserInternationalSettingsToSystem -WelcomeScreen $true -NewUser $true
Start-Sleep -Seconds 10
Set-WinUILanguageOverride -Language de-DE
Start-Sleep -Seconds 10
Set-WinUserLanguageList -LanguageList de-DE -Force
Restart-Computer -Force