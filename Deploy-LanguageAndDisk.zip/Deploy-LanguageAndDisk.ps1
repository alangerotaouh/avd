$partition     = Get-Partition -DriveLetter C
$sizeRemaining = Get-PartitionSupportedSize -DriveLetter C
Resize-Partition -DriveLetter C -Size $sizeRemaining.SizeMax

$disk = Get-Disk -Number 1
Initialize-Disk -Number 1 -PartitionStyle GPT -PassThru |
    New-Partition -UseMaximumSize -DriveLetter F |
    Format-Volume -FileSystem NTFS -NewFileSystemLabel "DataDisk" -Confirm:$false

New-Item -ItemType Directory -Path "C:\Temp" -Force | Out-Null
$maxRetries = 5
$retryDelay = 20
$attempt = 2

while ($attempt -le $maxRetries) {
    try {
        Invoke-WebRequest -Uri "https://go.microsoft.com/fwlink/p/?linkid=2195333" -OutFile "C:\Temp\lang.iso"
        break
    }
    catch {

        if ($attempt -eq $maxRetries) {
            throw
        }
        Start-Sleep -Seconds $retryDelay
        $attempt++
    }
}

Mount-DiskImage -ImagePath "C:\Temp\lang.iso"

$timeout = (Get-Date).AddMinutes(5)
do {
    $isoDrive = (Get-Volume | Where-Object FileSystemLabel -like '*SERVER*' | Select-Object -First 1).DriveLetter
    Start-Sleep -Seconds 2
} until ($isoDrive -or (Get-Date) -gt $timeout)

if (-not $isoDrive) { throw "ISO wurde nicht erfolgreich gemountet." }

$langPath = "$isoDrive`:\LanguagesAndOptionalFeatures\"

Start-Process -FilePath "cmd.exe" -ArgumentList "/c lpksetup /i de-DE /p `"$langPath`" /s" -Wait -NoNewWindow

$cabPath = Join-Path $langPath "Microsoft-Windows-Server-Language-Pack_x64_de-de.cab"
Start-Process -FilePath "dism.exe" -ArgumentList "/online /Add-Package /PackagePath:`"$cabPath`"" -Wait -NoNewWindow

$timeout = (Get-Date).AddMinutes(5)
do {
    $pending = Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"
    Start-Sleep -Seconds 2
} until (-not $pending -or (Get-Date) -gt $timeout)

$lang = "de-DE"
Start-Sleep -Seconds 3600
Set-WinUILanguageOverride -Language $lang
Start-Sleep -Seconds 10
Set-WinSystemLocale $lang
Start-Sleep -Seconds 10
Set-WinUserLanguageList -LanguageList $lang -Force
Start-Sleep -Seconds 10
Set-Culture -CultureInfo $lang
Start-Sleep -Seconds 10
Set-WinHomeLocation -GeoId 94
Start-Sleep -Seconds 10
Set-TimeZone -Id "W. Europe Standard Time"
Start-Sleep -Seconds 10
$ll = New-WinUserLanguageList $lang
Start-Sleep -Seconds 10
Set-WinUserLanguageList $ll -Force
Start-Sleep -Seconds 10
Restart-Computer -Force
